import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerComponent } from './components/customer/customer.component';


const routes: Routes = [
	{
		path: '',
		component: CustomerComponent
	},
	{
		path: 'customer',
		component: CustomerComponent
	}
];

export const components = [
	CustomerComponent
];


@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class CustomerRoutingModule { }
