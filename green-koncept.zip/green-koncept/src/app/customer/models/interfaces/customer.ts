export interface Customer {
	customerName: string;
	customerAge: number;
	customerAddress: string;
}
