import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { CustomerService } from 'src/app/core/services/customer/customer.service';

@Component({
	selector: 'app-customer',
	templateUrl: './customer.component.html',
	styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {

	formGroup: FormGroup;

	saved = false;
	customers: Array<any>;

	constructor(
		private authService: AuthService,
		private customerService: CustomerService,
		private formBuilder: FormBuilder,
		private router: Router) { }

	ngOnInit() {
		this.initFormGroup();
	}

	private initFormGroup(): void {
		this.formGroup = this.formBuilder.group({
			customerName: ['', Validators.required],
			customerAge: ['', Validators.required],
			customerAddress: ['', Validators.required]
		});
	}

	submit(): void {
		const { key } = this.authService.user;
		const customer = this.formGroup.getRawValue();

		this.customerService.addCustomer(customer, key)
			.subscribe(
				result => {
					this.saved = true;
					this.formGroup.reset();

					setTimeout(() => {
						this.saved = false;
					}, 2000);
				});
	}
}
