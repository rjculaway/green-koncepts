import { NgModule } from '@angular/core';
import { LoginRoutingModule, components } from './login-routing.module';
import { SharedModule } from '../shared/shared.module';


@NgModule({
	declarations: [components],
	imports: [
		SharedModule,

		LoginRoutingModule
	]
})
export class LoginModule { }
