import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from 'src/app/core/services/auth/auth.service';

@Component({
	selector: 'app-login',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

	formGroup: FormGroup;
	hasError: boolean;

	constructor(
		private authService: AuthService,
		private formBuilder: FormBuilder,
		private router: Router) { }

	ngOnInit() {
		this.initFormGroup();
	}

	private initFormGroup(): void {
		this.formGroup = this.formBuilder.group({
			username: ['', Validators.required],
			password: ['', Validators.required]
		});
	}

	login(): void {
		const username = this.formGroup.get('username').value;
		const password = this.formGroup.get('password').value;

		this.authService.login(username, password).subscribe(result => {
			this.router.navigate(['/dashboard']);
		},
			(error) => {
				this.hasError = true;
			});
	}

}
