import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { OrdersService } from 'src/app/core/services/orders/orders.service';

import { Order } from '@order/models/interfaces/order';

@Component({
	selector: 'app-orders',
	templateUrl: './orders.component.html',
	styleUrls: ['./orders.component.scss']
})
export class OrdersComponent implements OnInit {

	orders: Array<Order>;

	constructor(private authService: AuthService, private ordersService: OrdersService) { }

	ngOnInit() {
		this.getOrders();
	}

	private getOrders(): void {

		const { key } = this.authService.user;

		this.ordersService.getOrders(key).subscribe(result => {
			this.orders = result;

			console.log(this.orders);
		});
	}

}
