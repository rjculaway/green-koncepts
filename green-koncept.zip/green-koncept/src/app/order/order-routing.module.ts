import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrdersComponent } from './components/orders/orders.component';

const routes: Routes = [
	{
		path: '',
		component: OrdersComponent
	},
	{
		path: 'orders',
		component: OrdersComponent
	}
];

export const components = [
	OrdersComponent
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class OrderRoutingModule { }
