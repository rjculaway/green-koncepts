export interface Order {
	customerName: string;
	orderDate: Date;
	orderDetail: string;
	orderAmount: number;
}
