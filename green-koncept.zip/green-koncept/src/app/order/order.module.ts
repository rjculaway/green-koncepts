import { NgModule } from '@angular/core';

import { OrderRoutingModule, components } from './order-routing.module';
import { SharedModule } from '../shared/shared.module';


@NgModule({
	declarations: [components],
	imports: [
		SharedModule,
		OrderRoutingModule
	]
})
export class OrderModule { }
