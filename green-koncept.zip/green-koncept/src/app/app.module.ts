import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { httpClientProvider } from '@core/services/http-client/http-client.factory';

import { CoreModule } from '@core/core.module';
import { CustomerModule } from '@customer/customer.module';
import { DashboardModule } from '@dashboard/dashboard.module';
import { HeirarchyModule } from '@heirarchy/heirarchy.module';
import { LoginModule } from '@login/login.module';
import { OrderModule } from '@order/order.module';

@NgModule({
	declarations: [
		AppComponent
	],
	imports: [
		BrowserModule,

		AppRoutingModule,

		CoreModule,
		CustomerModule,
		DashboardModule,
		HeirarchyModule,
		LoginModule,
		OrderModule
	],
	providers: [
		httpClientProvider
	],
	bootstrap: [AppComponent]
})
export class AppModule { }
