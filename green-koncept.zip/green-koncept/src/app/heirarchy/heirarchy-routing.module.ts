import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeirarchyComponent } from './components/heirarchy/heirarchy.component';

const routes: Routes = [
	{
		path: '',
		component: HeirarchyComponent
	},
	{
		path: 'heirarchy',
		component: HeirarchyComponent
	}
];

export const components = [
	HeirarchyComponent
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class HeirarchyRoutingModule { }
