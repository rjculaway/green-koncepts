import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';

import { TreeviewModule } from 'ngx-treeview'

import { HeirarchyRoutingModule, components } from './heirarchy-routing.module';

@NgModule({
	declarations: [components],
	imports: [
		SharedModule,
		HeirarchyRoutingModule,

		TreeviewModule.forRoot()
	]
})
export class HeirarchyModule { }
