export interface Heirarchy {
	nodeId: string;
	nodeName: string;
	children?: Array<Heirarchy>;
}
