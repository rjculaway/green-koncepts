import { Component, OnInit } from '@angular/core';

import { AuthService } from '@core/services/auth/auth.service';
import { HeirarchyService } from '@core/services/heirarchy/heirarchy.service';
import { Heirarchy } from '@heirarchy/models/interfaces/heirarchy';
import { TreeItem, TreeviewConfig, TreeviewItem } from 'ngx-treeview';

@Component({
	selector: 'app-heirarchy',
	templateUrl: './heirarchy.component.html',
	styleUrls: ['./heirarchy.component.scss']
})
export class HeirarchyComponent implements OnInit {

	treeView: Array<TreeviewItem>;
	config: TreeviewConfig;

	constructor(private authService: AuthService, private heirarchyService: HeirarchyService) { }

	ngOnInit() {
		this.getHeirarchy();
		this.getTreeViewConfig();
	}

	private getTreeViewConfig(): void {
		this.config = {
			hasAllCheckBox: false,
			hasFilter: false,
			hasCollapseExpand: false,
			decoupleChildFromParent: false,
			maxHeight: 500,
			hasDivider: false
		};
	}

	private getHeirarchy(): void {
		const { key } = this.authService.user;
		const treeview = { text: null, value: null, children: [] };

		this.heirarchyService.getHeirarchy(key).subscribe(result => {
			const treeItem = this.GetTreeViewModel(result, treeview);
			this.treeView = [new TreeviewItem(treeItem)];
		});
	}

	private GetTreeViewModel(heirarchy: Heirarchy, treeview: TreeItem): TreeItem {
		Object.keys(heirarchy).forEach(key => {

			if (key === 'nodeName') {
				treeview.text = heirarchy.nodeName;
			}

			if (key === 'children') {
				if (heirarchy.children) {
					heirarchy.children.forEach(child => {
						const childTreeItem = { text: null, value: null, children: [] };
						treeview.children.push(this.GetTreeViewModel(child, childTreeItem));
					});
				}
			}
		});

		return treeview;
	}

}
