import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';

const components = [
	HeaderComponent,
	FooterComponent
];

@NgModule({
	declarations: [
		components
	],
	imports: [
		CommonModule,
		RouterModule,
		HttpClientModule
	],
	exports: [
		components,
		HttpClientModule
	]
})
export class CoreModule { }
