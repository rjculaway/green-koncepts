import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '@core/services/auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {

	isAuthorized = false;
	authServiceSubscription$: Subscription;

	constructor(private authService: AuthService, private router: Router) { }

	ngOnInit() {
		this.authService.isAuthorized$.subscribe(result => {
			this.isAuthorized = result;
		});
	}

	ngOnDestroy(): void {
		if (this.authServiceSubscription$) { this.authServiceSubscription$.unsubscribe(); }
	}

	logout(): void {
		this.authService.logout().subscribe(() => {
			this.router.navigate(['login']);
		})
	}

}
