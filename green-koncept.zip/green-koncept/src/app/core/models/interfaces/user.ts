export interface User {
	firstName: string;
	lastName: string;
	userName: string;
	key: string;
}
