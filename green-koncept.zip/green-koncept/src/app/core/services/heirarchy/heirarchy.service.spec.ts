import { TestBed } from '@angular/core/testing';

import { HeirarchyService } from './heirarchy.service';

describe('HeirarchyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HeirarchyService = TestBed.get(HeirarchyService);
    expect(service).toBeTruthy();
  });
});
