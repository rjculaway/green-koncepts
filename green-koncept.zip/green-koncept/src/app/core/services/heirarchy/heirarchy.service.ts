import { Injectable } from '@angular/core';
import { Heirarchy } from '@heirarchy/models/interfaces/heirarchy';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { HttpClientService } from '../http-client/http-client.service';

@Injectable({
	providedIn: 'root'
})
export class HeirarchyService {

	constructor(private httpClientService: HttpClientService) { }

	getHeirarchy(key: string): Observable<Heirarchy> {
		const url = `node-hierarchy?token=${key}`;
		return this.httpClientService.Get(this.httpClientService.getBaseUrl(url))
			.pipe(
				map((result: any) => {
					return result.entity.nodeStandardMetadata;
				})
			);
	}
}
