import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { HttpClientService } from '../http-client/http-client.service';
import { Order } from '@order/models/interfaces/order';

@Injectable({
	providedIn: 'root'
})
export class OrdersService {

	constructor(private httpClientService: HttpClientService) { }

	getOrders(key: string): Observable<Array<Order>> {
		const url = `getAllOrders?token=${key}`;
		return this.httpClientService.Get(this.httpClientService.getBaseUrl(url))
			.pipe(map((orders: Array<any>) => {
				return orders.map(order => {
					const newOrder: Order = {
						customerName: order.customer.customerName,
						orderDetail: order.orderDetail,
						orderDate: new Date(order.orderDate),
						orderAmount: order.orderAmount
					};

					return newOrder;
				});
			}));
	}
}
