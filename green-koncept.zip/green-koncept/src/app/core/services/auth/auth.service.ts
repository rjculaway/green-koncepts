import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { User } from '@core/models/interfaces/user';
import { HttpClientService } from '../http-client/http-client.service';

@Injectable({
	providedIn: 'root'
})
export class AuthService {

	user: User;
	isAuthorized$ = new BehaviorSubject<boolean>(false);

	constructor(private httpClientService: HttpClientService) { }

	login(username: string, password: string): Observable<any> {
		const url = `login?username=${username}&password=${password}`;

		return this.httpClientService.Get(this.httpClientService.getBaseUrl(url))
			.pipe(
				map((result: User) => {
					this.user = result;

					if (this.user) {
						this.isAuthorized$.next(true);
					}

					return result;
				})
			);
	}

	logout(): Observable<any> {
		const url = `logout?token=${this.user.key}`;

		return this.httpClientService.Get(this.httpClientService.getBaseUrl(url))
			.pipe(
				map((result: any) => {
					this.user = null;
					this.isAuthorized$.next(false);
					return result;
				})
			);
	}
}
