import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '@customer/models/interfaces/customer';
import { HttpClientService } from '../http-client/http-client.service';

@Injectable({
	providedIn: 'root'
})
export class CustomerService {

	constructor(private httpClientService: HttpClientService) { }

	addCustomer(customer: Customer, key: string): Observable<Customer> {
		const url = `createCustomer?token=${key}`;

		return this.httpClientService
			.Post(this.httpClientService.getBaseUrl(url), customer);
	}
}
